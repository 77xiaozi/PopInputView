//
//  NSFetchRequestDemoViewController.h
//  JKCategories
//
//  Created by Jakey on 15/6/5.
//  Copyright (c) 2015年 www.skyfox.org. All rights reserved.
//

#import "BaseViewController.h"

@interface NSFetchRequestDemoViewController : BaseViewController

@end
