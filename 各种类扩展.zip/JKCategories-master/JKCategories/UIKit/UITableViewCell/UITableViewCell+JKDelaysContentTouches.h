//
//  UITableViewCell+TS_delaysContentTouches.h
//  tableViewCellDelaysContentTouches
//
//  Created by Nicholas Hodapp on 1/31/14.
//  Copyright (c) 2014 Nicholas Hodapp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewCell (JKDelaysContentTouches)

@property (nonatomic, assign) BOOL jk_delaysContentTouches;

@end
