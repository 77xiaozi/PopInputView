//
//  JKCoreData.h
//  JKCategories
//
//  Created by Jakey on 16/5/29.
//  Copyright © 2016年 www.skyfox.org. All rights reserved.
//

#ifndef JKCoreData_h
#define JKCoreData_h

#import "NSFetchRequest+JKExtensions.h"
#import "NSManagedObject+JKDictionary.h"
#import "NSManagedObject+JKExtensions.h"
#import "NSManagedObjectContext+JKExtensions.h"
#import "NSManagedObjectContext+JKFetching.h"
#import "NSManagedObjectContext+JKFetchRequestsConstructors.h"
#import "NSManagedObjectContext+JKObjectClear.h"

#endif /* JKCoreData_h */
