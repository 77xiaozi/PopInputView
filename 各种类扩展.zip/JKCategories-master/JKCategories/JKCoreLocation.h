//
//  JKCoreLocation.h
//  JKCategories
//
//  Created by Jakey on 16/5/29.
//  Copyright © 2016年 www.skyfox.org. All rights reserved.
//

#ifndef JKCoreLocation_h
#define JKCoreLocation_h

#import "CLLocation+JKCH1903.h"

#endif /* JKCoreLocation_h */
