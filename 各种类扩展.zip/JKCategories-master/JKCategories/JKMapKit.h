//
//  JKMapKit.h
//  JKCategories
//
//  Created by Jakey on 16/5/29.
//  Copyright © 2016年 www.skyfox.org. All rights reserved.
//

#ifndef JKMapKit_h
#define JKMapKit_h

#import "MKMapView+JKBetterMaps.h"
#import "MKMapView+JKMoveLogo.h"
#import "MKMapView+JKZoomLevel.h"

#endif /* JKMapKit_h */
